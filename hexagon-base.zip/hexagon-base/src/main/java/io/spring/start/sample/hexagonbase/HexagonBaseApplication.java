package io.spring.start.sample.hexagonbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HexagonBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(HexagonBaseApplication.class, args);
	}

}
